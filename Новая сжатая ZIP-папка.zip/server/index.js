require('dotenv').config({ path: __dirname + '/.env' });

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' },
  maxHttpBufferSize: 50 * 1024 * 1024
});

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'impuls_secret_2024';

// ============ DATABASE SETUP ============
const dbPath = path.join(__dirname, '..', 'impuls.db');
const db = new Database(dbPath);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    display_name TEXT NOT NULL,
    avatar TEXT DEFAULT '',
    bio TEXT DEFAULT '',
    status TEXT DEFAULT 'offline',
    last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS chats (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL DEFAULT 'private',
    name TEXT DEFAULT '',
    avatar TEXT DEFAULT '',
    description TEXT DEFAULT '',
    created_by TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS chat_members (
    chat_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    role TEXT DEFAULT 'member',
    joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    muted INTEGER DEFAULT 0,
    pinned INTEGER DEFAULT 0,
    PRIMARY KEY (chat_id, user_id),
    FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    chat_id TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    content TEXT DEFAULT '',
    type TEXT DEFAULT 'text',
    file_url TEXT DEFAULT '',
    file_name TEXT DEFAULT '',
    file_size INTEGER DEFAULT 0,
    reply_to TEXT DEFAULT '',
    forwarded_from TEXT DEFAULT '',
    edited INTEGER DEFAULT 0,
    edited_at DATETIME,
    deleted INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS message_reads (
    message_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    read_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (message_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS message_reactions (
    id TEXT PRIMARY KEY,
    message_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    emoji TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(message_id, user_id, emoji),
    FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS contacts (
    user_id TEXT NOT NULL,
    contact_id TEXT NOT NULL,
    blocked INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, contact_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (contact_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS typing_status (
    chat_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    is_typing INTEGER DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (chat_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS stories (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    content TEXT NOT NULL,
    type TEXT DEFAULT 'text',
    file_url TEXT DEFAULT '',
    bg_color TEXT DEFAULT '#667eea',
    views INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS story_views (
    story_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    viewed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (story_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS calls (
    id TEXT PRIMARY KEY,
    caller_id TEXT NOT NULL,
    chat_id TEXT NOT NULL,
    type TEXT DEFAULT 'voice',
    status TEXT DEFAULT 'pending',
    started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    ended_at DATETIME,
    duration INTEGER DEFAULT 0
  );

  CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_chat_members_user ON chat_members(user_id);
  CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id);
  CREATE INDEX IF NOT EXISTS idx_stories_user ON stories(user_id);
`);

// ============ MIDDLEWARE ============
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

const publicPath = path.join(__dirname, '..', 'public');
const uploadsPath = path.join(publicPath, 'uploads');

if (!fs.existsSync(uploadsPath)) {
  fs.mkdirSync(uploadsPath, { recursive: true });
}

app.use(express.static(publicPath));
app.use('/uploads', express.static(uploadsPath));

// File upload config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const type = file.mimetype.startsWith('image/') ? 'images' :
                 file.mimetype.startsWith('video/') ? 'videos' :
                 file.mimetype.startsWith('audio/') ? 'audio' : 'files';
    const dir = path.join(uploadsPath, type);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }
});

// Auth middleware
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Нет токена авторизации' });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Невалидный токен' });
  }
}

// ============ AUTH ROUTES ============
app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, email, password, displayName } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ error: 'Заполните все поля' });
    }

    if (username.length < 3) {
      return res.status(400).json({ error: 'Имя пользователя минимум 3 символа' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Пароль минимум 6 символов' });
    }

    const existing = db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(username.toLowerCase(), email.toLowerCase());
    if (existing) {
      return res.status(400).json({ error: 'Пользователь уже существует' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const userId = uuidv4();

    db.prepare(`
      INSERT INTO users (id, username, email, password, display_name, status)
      VALUES (?, ?, ?, ?, ?, 'online')
    `).run(userId, username.toLowerCase(), email.toLowerCase(), hashedPassword, displayName || username);

    const token = jwt.sign({ userId }, JWT_SECRET, { expiresIn: '30d' });

    const user = db.prepare('SELECT id, username, email, display_name, avatar, bio, status FROM users WHERE id = ?').get(userId);

    res.json({ token, user });
  } catch (e) {
    console.error('Register error:', e);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { login, password } = req.body;

    if (!login || !password) {
      return res.status(400).json({ error: 'Заполните все поля' });
    }

    const user = db.prepare('SELECT * FROM users WHERE username = ? OR email = ?').get(login.toLowerCase(), login.toLowerCase());
    if (!user) {
      return res.status(400).json({ error: 'Пользователь не найден' });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(400).json({ error: 'Неверный пароль' });
    }

    db.prepare('UPDATE users SET status = ?, last_seen = CURRENT_TIMESTAMP WHERE id = ?').run('online', user.id);

    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '30d' });

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        display_name: user.display_name,
        avatar: user.avatar,
        bio: user.bio,
        status: 'online'
      }
    });
  } catch (e) {
    console.error('Login error:', e);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

// ============ USER ROUTES ============
app.get('/api/users/me', authMiddleware, (req, res) => {
  const user = db.prepare('SELECT id, username, email, display_name, avatar, bio, status FROM users WHERE id = ?').get(req.userId);
  if (!user) return res.status(404).json({ error: 'Пользователь не найден' });
  res.json(user);
});

app.put('/api/users/me', authMiddleware, (req, res) => {
  const { displayName, bio, avatar } = req.body;
  db.prepare('UPDATE users SET display_name = COALESCE(?, display_name), bio = COALESCE(?, bio), avatar = COALESCE(?, avatar) WHERE id = ?')
    .run(displayName, bio, avatar, req.userId);

  const user = db.prepare('SELECT id, username, email, display_name, avatar, bio, status FROM users WHERE id = ?').get(req.userId);
  res.json(user);
});

app.get('/api/users/search', authMiddleware, (req, res) => {
  const { q } = req.query;
  if (!q || q.length < 2) return res.json([]);

  const users = db.prepare(`
    SELECT id, username, display_name, avatar, bio, status
    FROM users
    WHERE (username LIKE ? OR display_name LIKE ?) AND id != ?
    LIMIT 20
  `).all(`%${q}%`, `%${q}%`, req.userId);

  res.json(users);
});

app.get('/api/users/:userId', authMiddleware, (req, res) => {
  const user = db.prepare('SELECT id, username, display_name, avatar, bio, status, last_seen FROM users WHERE id = ?').get(req.params.userId);
  if (!user) return res.status(404).json({ error: 'Не найден' });
  res.json(user);
});

// ============ CHAT ROUTES ============
app.get('/api/chats', authMiddleware, (req, res) => {
  const chats = db.prepare(`
    SELECT c.*, cm.role, cm.muted, cm.pinned,
    (SELECT COUNT(*) FROM messages m WHERE m.chat_id = c.id AND m.deleted = 0
     AND m.id NOT IN (SELECT message_id FROM message_reads WHERE user_id = ?)
     AND m.sender_id != ?) as unread_count
    FROM chats c
    JOIN chat_members cm ON c.id = cm.chat_id
    WHERE cm.user_id = ?
    ORDER BY cm.pinned DESC,
    (SELECT MAX(created_at) FROM messages WHERE chat_id = c.id) DESC
  `).all(req.userId, req.userId, req.userId);

  const result = chats.map(chat => {
    const lastMessage = db.prepare(`
      SELECT m.*, u.display_name as sender_name
      FROM messages m
      JOIN users u ON m.sender_id = u.id
      WHERE m.chat_id = ? AND m.deleted = 0
      ORDER BY m.created_at DESC
      LIMIT 1
    `).get(chat.id);

    const members = db.prepare(`
      SELECT u.id, u.username, u.display_name, u.avatar, u.status, cm.role
      FROM chat_members cm
      JOIN users u ON cm.user_id = u.id
      WHERE cm.chat_id = ?
    `).all(chat.id);

    let chatName = chat.name;
    let chatAvatar = chat.avatar;
    if (chat.type === 'private') {
      const other = members.find(m => m.id !== req.userId);
      if (other) {
        chatName = other.display_name;
        chatAvatar = other.avatar;
      }
    }

    return {
      ...chat,
      name: chatName,
      avatar: chatAvatar,
      last_message: lastMessage || null,
      members,
      member_count: members.length
    };
  });

  res.json(result);
});

app.post('/api/chats', authMiddleware, (req, res) => {
  const { type, name, members, description } = req.body;

  if (type === 'private') {
    if (!members || members.length !== 1) {
      return res.status(400).json({ error: 'Укажите одного участника' });
    }

    const existingChat = db.prepare(`
      SELECT c.id FROM chats c
      WHERE c.type = 'private'
      AND EXISTS (SELECT 1 FROM chat_members WHERE chat_id = c.id AND user_id = ?)
      AND EXISTS (SELECT 1 FROM chat_members WHERE chat_id = c.id AND user_id = ?)
    `).get(req.userId, members[0]);

    if (existingChat) {
      const chat = db.prepare('SELECT * FROM chats WHERE id = ?').get(existingChat.id);
      return res.json(chat);
    }
  }

  const chatId = uuidv4();

  db.prepare(`
    INSERT INTO chats (id, type, name, description, created_by)
    VALUES (?, ?, ?, ?, ?)
  `).run(chatId, type || 'private', name || '', description || '', req.userId);

  db.prepare('INSERT INTO chat_members (chat_id, user_id, role) VALUES (?, ?, ?)').run(chatId, req.userId, 'admin');

  if (members) {
    const insertMember = db.prepare('INSERT OR IGNORE INTO chat_members (chat_id, user_id, role) VALUES (?, ?, ?)');
    members.forEach(memberId => {
      insertMember.run(chatId, memberId, 'member');
    });
  }

  if (type === 'group' || type === 'channel') {
    const systemMsgId = uuidv4();
    db.prepare(`
      INSERT INTO messages (id, chat_id, sender_id, content, type)
      VALUES (?, ?, ?, ?, 'system')
    `).run(systemMsgId, chatId, req.userId, `Создан ${type === 'group' ? 'группа' : 'канал'} "${name}"`);
  }

  const chat = db.prepare('SELECT * FROM chats WHERE id = ?').get(chatId);
  res.json(chat);
});

app.post('/api/chats/:chatId/members', authMiddleware, (req, res) => {
  const { userId } = req.body;
  const { chatId } = req.params;

  const member = db.prepare('SELECT role FROM chat_members WHERE chat_id = ? AND user_id = ?').get(chatId, req.userId);
  if (!member || (member.role !== 'admin' && member.role !== 'moderator')) {
    return res.status(403).json({ error: 'Нет прав' });
  }

  db.prepare('INSERT OR IGNORE INTO chat_members (chat_id, user_id) VALUES (?, ?)').run(chatId, userId);

  const systemMsgId = uuidv4();
  const addedUser = db.prepare('SELECT display_name FROM users WHERE id = ?').get(userId);
  db.prepare(`
    INSERT INTO messages (id, chat_id, sender_id, content, type)
    VALUES (?, ?, ?, ?, 'system')
  `).run(systemMsgId, chatId, req.userId, `${addedUser?.display_name || 'Пользователь'} добавлен в чат`);

  res.json({ success: true });
});

app.delete('/api/chats/:chatId/members/:userId', authMiddleware, (req, res) => {
  const { chatId, userId } = req.params;

  if (userId !== req.userId) {
    const member = db.prepare('SELECT role FROM chat_members WHERE chat_id = ? AND user_id = ?').get(chatId, req.userId);
    if (!member || member.role !== 'admin') {
      return res.status(403).json({ error: 'Нет прав' });
    }
  }

  db.prepare('DELETE FROM chat_members WHERE chat_id = ? AND user_id = ?').run(chatId, userId);
  res.json({ success: true });
});

app.put('/api/chats/:chatId', authMiddleware, (req, res) => {
  const { name, description, avatar } = req.body;
  const { chatId } = req.params;

  const member = db.prepare('SELECT role FROM chat_members WHERE chat_id = ? AND user_id = ?').get(chatId, req.userId);
  if (!member || member.role !== 'admin') {
    return res.status(403).json({ error: 'Нет прав' });
  }

  db.prepare('UPDATE chats SET name = COALESCE(?, name), description = COALESCE(?, description), avatar = COALESCE(?, avatar) WHERE id = ?')
    .run(name, description, avatar, chatId);

  const chat = db.prepare('SELECT * FROM chats WHERE id = ?').get(chatId);
  res.json(chat);
});

app.put('/api/chats/:chatId/settings', authMiddleware, (req, res) => {
  const { muted, pinned } = req.body;
  const { chatId } = req.params;

  if (muted !== undefined) {
    db.prepare('UPDATE chat_members SET muted = ? WHERE chat_id = ? AND user_id = ?').run(muted ? 1 : 0, chatId, req.userId);
  }
  if (pinned !== undefined) {
    db.prepare('UPDATE chat_members SET pinned = ? WHERE chat_id = ? AND user_id = ?').run(pinned ? 1 : 0, chatId, req.userId);
  }

  res.json({ success: true });
});

// ============ MESSAGE ROUTES ============
app.get('/api/chats/:chatId/messages', authMiddleware, (req, res) => {
  const { chatId } = req.params;
  const { before, limit = 50 } = req.query;

  const member = db.prepare('SELECT 1 FROM chat_members WHERE chat_id = ? AND user_id = ?').get(chatId, req.userId);
  if (!member) return res.status(403).json({ error: 'Нет доступа' });

  let query = `
    SELECT m.*, u.display_name as sender_name, u.avatar as sender_avatar, u.username as sender_username
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.chat_id = ?
  `;
  const params = [chatId];

  if (before) {
    query += ' AND m.created_at < ?';
    params.push(before);
  }

  query += ' ORDER BY m.created_at DESC LIMIT ?';
  params.push(parseInt(limit));

  let messages = db.prepare(query).all(...params);

  messages = messages.map(msg => {
    const reactions = db.prepare(`
      SELECT mr.emoji, mr.user_id, u.display_name
      FROM message_reactions mr
      JOIN users u ON mr.user_id = u.id
      WHERE mr.message_id = ?
    `).all(msg.id);

    const reads = db.prepare(`
      SELECT user_id, read_at FROM message_reads WHERE message_id = ?
    `).all(msg.id);

    let replyMessage = null;
    if (msg.reply_to) {
      replyMessage = db.prepare(`
        SELECT m.id, m.content, m.type, u.display_name as sender_name
        FROM messages m JOIN users u ON m.sender_id = u.id
        WHERE m.id = ?
      `).get(msg.reply_to);
    }

    return {
      ...msg,
      reactions,
      reads,
      reply_message: replyMessage,
      deleted: !!msg.deleted,
      edited: !!msg.edited
    };
  });

  res.json(messages.reverse());
});

app.get('/api/chats/:chatId/messages/search', authMiddleware, (req, res) => {
  const { chatId } = req.params;
  const { q } = req.query;

  if (!q) return res.json([]);

  const messages = db.prepare(`
    SELECT m.*, u.display_name as sender_name, u.avatar as sender_avatar
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.chat_id = ? AND m.content LIKE ? AND m.deleted = 0
    ORDER BY m.created_at DESC
    LIMIT 50
  `).all(chatId, `%${q}%`);

  res.json(messages);
});

// ============ FILE UPLOAD ============
app.post('/api/upload', authMiddleware, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Нет файла' });

  const type = req.file.mimetype.startsWith('image/') ? 'images' :
               req.file.mimetype.startsWith('video/') ? 'videos' :
               req.file.mimetype.startsWith('audio/') ? 'audio' : 'files';

  res.json({
    url: `/uploads/${type}/${req.file.filename}`,
    name: req.file.originalname,
    size: req.file.size,
    mimetype: req.file.mimetype
  });
});

app.post('/api/upload/avatar', authMiddleware, upload.single('avatar'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Нет файла' });

  const type = 'images';
  const url = `/uploads/${type}/${req.file.filename}`;

  db.prepare('UPDATE users SET avatar = ? WHERE id = ?').run(url, req.userId);

  res.json({ url });
});

// ============ STORIES ============
app.get('/api/stories', authMiddleware, (req, res) => {
  const stories = db.prepare(`
    SELECT s.*, u.display_name, u.avatar as user_avatar, u.username
    FROM stories s
    JOIN users u ON s.user_id = u.id
    WHERE s.expires_at > CURRENT_TIMESTAMP OR s.expires_at IS NULL
    ORDER BY s.created_at DESC
  `).all();

  const grouped = {};
  stories.forEach(story => {
    if (!grouped[story.user_id]) {
      grouped[story.user_id] = {
        user_id: story.user_id,
        display_name: story.display_name,
        avatar: story.user_avatar,
        username: story.username,
        stories: []
      };
    }

    const viewed = db.prepare('SELECT 1 FROM story_views WHERE story_id = ? AND user_id = ?').get(story.id, req.userId);
    grouped[story.user_id].stories.push({
      ...story,
      viewed: !!viewed
    });
  });

  res.json(Object.values(grouped));
});

app.post('/api/stories', authMiddleware, (req, res) => {
  const { content, type, fileUrl, bgColor } = req.body;
  const storyId = uuidv4();

  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

  db.prepare(`
    INSERT INTO stories (id, user_id, content, type, file_url, bg_color, expires_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(storyId, req.userId, content || '', type || 'text', fileUrl || '', bgColor || '#667eea', expiresAt);

  const story = db.prepare('SELECT * FROM stories WHERE id = ?').get(storyId);
  res.json(story);
});

app.post('/api/stories/:storyId/view', authMiddleware, (req, res) => {
  db.prepare('INSERT OR IGNORE INTO story_views (story_id, user_id) VALUES (?, ?)').run(req.params.storyId, req.userId);
  db.prepare('UPDATE stories SET views = views + 1 WHERE id = ?').run(req.params.storyId);
  res.json({ success: true });
});

// ============ CONTACTS ============
app.get('/api/contacts', authMiddleware, (req, res) => {
  const contacts = db.prepare(`
    SELECT u.id, u.username, u.display_name, u.avatar, u.bio, u.status, u.last_seen, c.blocked
    FROM contacts c
    JOIN users u ON c.contact_id = u.id
    WHERE c.user_id = ?
    ORDER BY u.display_name
  `).all(req.userId);

  res.json(contacts);
});

app.post('/api/contacts', authMiddleware, (req, res) => {
  const { contactId } = req.body;
  db.prepare('INSERT OR IGNORE INTO contacts (user_id, contact_id) VALUES (?, ?)').run(req.userId, contactId);
  res.json({ success: true });
});

app.delete('/api/contacts/:contactId', authMiddleware, (req, res) => {
  db.prepare('DELETE FROM contacts WHERE user_id = ? AND contact_id = ?').run(req.userId, req.params.contactId);
  res.json({ success: true });
});

app.put('/api/contacts/:contactId/block', authMiddleware, (req, res) => {
  const { blocked } = req.body;
  db.prepare('UPDATE contacts SET blocked = ? WHERE user_id = ? AND contact_id = ?').run(blocked ? 1 : 0, req.userId, req.params.contactId);
  res.json({ success: true });
});

// ============ PAGES ============
app.get('/', (req, res) => {
  res.sendFile(path.join(publicPath, 'index.html'));
});

app.get('/app', (req, res) => {
  res.sendFile(path.join(publicPath, 'app.html'));
});

// ============ SOCKET.IO ============
const onlineUsers = new Map();

function authenticateSocket(socket, next) {
  const token = socket.handshake.auth.token;
  if (!token) return next(new Error('Нет токена'));

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    socket.userId = decoded.userId;
    next();
  } catch (e) {
    next(new Error('Невалидный токен'));
  }
}

io.use(authenticateSocket);

io.on('connection', (socket) => {
  const userId = socket.userId;
  console.log(`User connected: ${userId}`);

  onlineUsers.set(userId, socket.id);
  db.prepare('UPDATE users SET status = ?, last_seen = CURRENT_TIMESTAMP WHERE id = ?').run('online', userId);

  // Join all user's chats
  const userChats = db.prepare('SELECT chat_id FROM chat_members WHERE user_id = ?').all(userId);
  userChats.forEach(({ chat_id }) => {
    socket.join(`chat:${chat_id}`);
  });

  // Broadcast online status
  io.emit('user:status', { userId, status: 'online' });

  // ---- MESSAGES ----
  socket.on('message:send', (data) => {
    try {
      const { chatId, content, type, fileUrl, fileName, fileSize, replyTo, forwardedFrom } = data;

      const member = db.prepare('SELECT 1 FROM chat_members WHERE chat_id = ? AND user_id = ?').get(chatId, userId);
      if (!member) return;

      const messageId = uuidv4();

      db.prepare(`
        INSERT INTO messages (id, chat_id, sender_id, content, type, file_url, file_name, file_size, reply_to, forwarded_from)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(messageId, chatId, userId, content || '', type || 'text', fileUrl || '', fileName || '', fileSize || 0, replyTo || '', forwardedFrom || '');

      const message = db.prepare(`
        SELECT m.*, u.display_name as sender_name, u.avatar as sender_avatar, u.username as sender_username
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE m.id = ?
      `).get(messageId);

      let replyMessage = null;
      if (replyTo) {
        replyMessage = db.prepare(`
          SELECT m.id, m.content, m.type, u.display_name as sender_name
          FROM messages m JOIN users u ON m.sender_id = u.id
          WHERE m.id = ?
        `).get(replyTo);
      }

      const fullMessage = {
        ...message,
        reactions: [],
        reads: [],
        reply_message: replyMessage,
        deleted: false,
        edited: false
      };

      io.to(`chat:${chatId}`).emit('message:new', fullMessage);

      // Send notification to offline members
      const members = db.prepare('SELECT user_id FROM chat_members WHERE chat_id = ? AND user_id != ?').all(chatId, userId);
      members.forEach(m => {
        const memberSocket = onlineUsers.get(m.user_id);
        if (memberSocket) {
          io.to(memberSocket).emit('notification', {
            type: 'message',
            chatId,
            message: fullMessage
          });
        }
      });
    } catch (e) {
      console.error('Message send error:', e);
    }
  });

  socket.on('message:edit', (data) => {
    const { messageId, content } = data;

    const msg = db.prepare('SELECT * FROM messages WHERE id = ? AND sender_id = ?').get(messageId, userId);
    if (!msg) return;

    db.prepare('UPDATE messages SET content = ?, edited = 1, edited_at = CURRENT_TIMESTAMP WHERE id = ?').run(content, messageId);

    io.to(`chat:${msg.chat_id}`).emit('message:edited', {
      messageId,
      content,
      edited: true,
      edited_at: new Date().toISOString()
    });
  });

  socket.on('message:delete', (data) => {
    const { messageId } = data;

    const msg = db.prepare('SELECT * FROM messages WHERE id = ? AND sender_id = ?').get(messageId, userId);
    if (!msg) return;

    db.prepare('UPDATE messages SET deleted = 1, content = "" WHERE id = ?').run(messageId);

    io.to(`chat:${msg.chat_id}`).emit('message:deleted', { messageId, chatId: msg.chat_id });
  });

  socket.on('message:read', (data) => {
    const { chatId, messageIds } = data;

    const insertRead = db.prepare('INSERT OR IGNORE INTO message_reads (message_id, user_id) VALUES (?, ?)');
    const readTransaction = db.transaction((ids) => {
      ids.forEach(id => insertRead.run(id, userId));
    });

    readTransaction(messageIds);

    io.to(`chat:${chatId}`).emit('message:read', {
      chatId,
      messageIds,
      userId,
      readAt: new Date().toISOString()
    });
  });

  socket.on('message:reaction', (data) => {
    const { messageId, emoji } = data;

    const existing = db.prepare('SELECT id FROM message_reactions WHERE message_id = ? AND user_id = ? AND emoji = ?').get(messageId, userId, emoji);

    if (existing) {
      db.prepare('DELETE FROM message_reactions WHERE id = ?').run(existing.id);
    } else {
      db.prepare('INSERT INTO message_reactions (id, message_id, user_id, emoji) VALUES (?, ?, ?, ?)').run(uuidv4(), messageId, userId, emoji);
    }

    const msg = db.prepare('SELECT chat_id FROM messages WHERE id = ?').get(messageId);
    if (msg) {
      const reactions = db.prepare(`
        SELECT mr.emoji, mr.user_id, u.display_name
        FROM message_reactions mr
        JOIN users u ON mr.user_id = u.id
        WHERE mr.message_id = ?
      `).all(messageId);

      io.to(`chat:${msg.chat_id}`).emit('message:reaction:updated', {
        messageId,
        reactions
      });
    }
  });

  // ---- TYPING ----
  socket.on('typing:start', (data) => {
    const { chatId } = data;
    const user = db.prepare('SELECT display_name FROM users WHERE id = ?').get(userId);
    socket.to(`chat:${chatId}`).emit('typing:update', {
      chatId,
      userId,
      displayName: user?.display_name || 'User',
      isTyping: true
    });
  });

  socket.on('typing:stop', (data) => {
    const { chatId } = data;
    socket.to(`chat:${chatId}`).emit('typing:update', {
      chatId,
      userId,
      isTyping: false
    });
  });

  // ---- CALLS ----
  socket.on('call:start', (data) => {
    const { chatId, type } = data;
    const callId = uuidv4();

    db.prepare('INSERT INTO calls (id, caller_id, chat_id, type) VALUES (?, ?, ?, ?)').run(callId, userId, chatId, type || 'voice');

    const caller = db.prepare('SELECT display_name, avatar FROM users WHERE id = ?').get(userId);

    io.to(`chat:${chatId}`).emit('call:incoming', {
      callId,
      callerId: userId,
      callerName: caller?.display_name,
      callerAvatar: caller?.avatar,
      chatId,
      type: type || 'voice'
    });
  });

  socket.on('call:accept', (data) => {
    const { callId, chatId } = data;
    io.to(`chat:${chatId}`).emit('call:accepted', { callId, userId });
  });

  socket.on('call:reject', (data) => {
    const { callId, chatId } = data;
    db.prepare('UPDATE calls SET status = ?, ended_at = CURRENT_TIMESTAMP WHERE id = ?').run('rejected', callId);
    io.to(`chat:${chatId}`).emit('call:rejected', { callId, userId });
  });

  socket.on('call:end', (data) => {
    const { callId, chatId } = data;
    db.prepare('UPDATE calls SET status = ?, ended_at = CURRENT_TIMESTAMP WHERE id = ?').run('ended', callId);
    io.to(`chat:${chatId}`).emit('call:ended', { callId, userId });
  });

  // ---- WEBRTC SIGNALING ----
  socket.on('webrtc:offer', (data) => {
    const { targetUserId, offer } = data;
    const targetSocket = onlineUsers.get(targetUserId);
    if (targetSocket) {
      io.to(targetSocket).emit('webrtc:offer', { offer, from: userId });
    }
  });

  socket.on('webrtc:answer', (data) => {
    const { targetUserId, answer } = data;
    const targetSocket = onlineUsers.get(targetUserId);
    if (targetSocket) {
      io.to(targetSocket).emit('webrtc:answer', { answer, from: userId });
    }
  });

  socket.on('webrtc:ice-candidate', (data) => {
    const { targetUserId, candidate } = data;
    const targetSocket = onlineUsers.get(targetUserId);
    if (targetSocket) {
      io.to(targetSocket).emit('webrtc:ice-candidate', { candidate, from: userId });
    }
  });

  // ---- CHAT MANAGEMENT ----
  socket.on('chat:join', (data) => {
    socket.join(`chat:${data.chatId}`);
  });

  socket.on('chat:leave', (data) => {
    socket.leave(`chat:${data.chatId}`);
  });

  // ---- DISCONNECT ----
  socket.on('disconnect', () => {
    onlineUsers.delete(userId);
    db.prepare('UPDATE users SET status = ?, last_seen = CURRENT_TIMESTAMP WHERE id = ?').run('offline', userId);
    io.emit('user:status', { userId, status: 'offline', lastSeen: new Date().toISOString() });
    console.log(`User disconnected: ${userId}`);
  });
});

// Start server
server.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔══════════════════════════════════════════╗
║          IMPULS MESSENGER v1.0           ║
║──────────────────────────────────────────║
║  Server running on port ${PORT}             ║
║  http://localhost:${PORT}                   ║
╚══════════════════════════════════════════╝
  `);
});