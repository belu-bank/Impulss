// Redirect if already logged in
if (localStorage.getItem('impuls_token')) {
  window.location.href = '/app';
}

// Create particles
(function createParticles() {
  const container = document.getElementById('particles');
  for (let i = 0; i < 30; i++) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    const size = Math.random() * 6 + 2;
    particle.style.width = size + 'px';
    particle.style.height = size + 'px';
    particle.style.left = Math.random() * 100 + '%';
    particle.style.animationDuration = Math.random() * 15 + 10 + 's';
    particle.style.animationDelay = Math.random() * 10 + 's';
    container.appendChild(particle);
  }
})();

function switchTab(tab) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.form').forEach(f => f.classList.remove('active'));

  if (tab === 'login') {
    document.querySelectorAll('.tab')[0].classList.add('active');
    document.getElementById('loginForm').classList.add('active');
  } else {
    document.querySelectorAll('.tab')[1].classList.add('active');
    document.getElementById('registerForm').classList.add('active');
  }

  hideError();
}

function showError(msg) {
  const el = document.getElementById('errorMsg');
  el.textContent = msg;
  el.style.display = 'block';
}

function hideError() {
  document.getElementById('errorMsg').style.display = 'none';
}

async function handleLogin(e) {
  e.preventDefault();
  hideError();

  const btn = document.getElementById('loginBtn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Вход...';

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        login: document.getElementById('loginInput').value.trim(),
        password: document.getElementById('loginPassword').value
      })
    });

    const data = await res.json();

    if (!res.ok) {
      showError(data.error || 'Ошибка входа');
      return;
    }

    localStorage.setItem('impuls_token', data.token);
    localStorage.setItem('impuls_user', JSON.stringify(data.user));
    window.location.href = '/app';
  } catch (err) {
    showError('Ошибка соединения с сервером');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Войти';
  }
}

async function handleRegister(e) {
  e.preventDefault();
  hideError();

  const btn = document.getElementById('regBtn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Создание...';

  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: document.getElementById('regUsername').value.trim(),
        displayName: document.getElementById('regDisplayName').value.trim(),
        email: document.getElementById('regEmail').value.trim(),
        password: document.getElementById('regPassword').value
      })
    });

    const data = await res.json();

    if (!res.ok) {
      showError(data.error || 'Ошибка регистрации');
      return;
    }

    localStorage.setItem('impuls_token', data.token);
    localStorage.setItem('impuls_user', JSON.stringify(data.user));
    window.location.href = '/app';
  } catch (err) {
    showError('Ошибка соединения с сервером');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-user-plus"></i> Создать аккаунт';
  }
}