// ============ STATE ============
const state = {
  token: localStorage.getItem('impuls_token'),
  user: JSON.parse(localStorage.getItem('impuls_user') || 'null'),
  chats: [],
  currentChat: null,
  messages: [],
  socket: null,
  replyTo: null,
  selectedMembers: [],
  typingTimers: {},
  theme: localStorage.getItem('impuls_theme') || 'dark',
  emojiList: [],
  storyColor: '#667eea'
};

// Redirect if not authenticated
if (!state.token || !state.user) {
  window.location.href = '/';
}

// Apply theme
if (state.theme === 'light') {
  document.documentElement.setAttribute('data-theme', 'light');
}

// ============ SOCKET CONNECTION ============
function connectSocket() {
  state.socket = io({
    auth: { token: state.token }
  });

  state.socket.on('connect', () => {
    console.log('Connected to IMPULS server');
    loadChats();
    loadStories();
  });

  state.socket.on('connect_error', (err) => {
    console.error('Socket connection error:', err);
    if (err.message === 'Невалидный токен') {
      logout();
    }
  });

  // New message
  state.socket.on('message:new', (message) => {
    // Update chat list
    const chatIndex = state.chats.findIndex(c => c.id === message.chat_id);
    if (chatIndex > -1) {
      state.chats[chatIndex].last_message = message;
      if (state.currentChat?.id !== message.chat_id) {
        state.chats[chatIndex].unread_count = (state.chats[chatIndex].unread_count || 0) + 1;
      }
      renderChatList();
    } else {
      loadChats();
    }

    // Add to current chat messages
    if (state.currentChat?.id === message.chat_id) {
      state.messages.push(message);
      renderNewMessage(message);
      scrollToBottom();

      // Mark as read
      if (message.sender_id !== state.user.id) {
        state.socket.emit('message:read', {
          chatId: message.chat_id,
          messageIds: [message.id]
        });
      }
    }

    // Play notification sound
    if (message.sender_id !== state.user.id) {
      playNotificationSound();
    }
  });

  // Message edited
  state.socket.on('message:edited', (data) => {
    const msgEl = document.querySelector(`[data-msg-id="${data.messageId}"]`);
    if (msgEl) {
      const contentEl = msgEl.querySelector('.message-content');
      if (contentEl) contentEl.textContent = data.content;
      if (!msgEl.querySelector('.message-edited')) {
        const metaEl = msgEl.querySelector('.message-meta');
        if (metaEl) {
          const editedSpan = document.createElement('span');
          editedSpan.className = 'message-edited';
          editedSpan.textContent = 'изменено';
          metaEl.prepend(editedSpan);
        }
      }
    }

    const msgIndex = state.messages.findIndex(m => m.id === data.messageId);
    if (msgIndex > -1) {
      state.messages[msgIndex].content = data.content;
      state.messages[msgIndex].edited = true;
    }
  });

  // Message deleted
  state.socket.on('message:deleted', (data) => {
    const msgEl = document.querySelector(`[data-msg-id="${data.messageId}"]`);
    if (msgEl) {
      const contentEl = msgEl.querySelector('.message-content');
      if (contentEl) {
        contentEl.innerHTML = '<span class="message-deleted"><i class="fas fa-ban"></i> Сообщение удалено</span>';
      }
      // Remove reactions
      const reactionsEl = msgEl.querySelector('.message-reactions');
      if (reactionsEl) reactionsEl.remove();
    }

    const msgIndex = state.messages.findIndex(m => m.id === data.messageId);
    if (msgIndex > -1) {
      state.messages[msgIndex].deleted = true;
      state.messages[msgIndex].content = '';
    }
  });

  // Message read
  state.socket.on('message:read', (data) => {
    if (state.currentChat?.id === data.chatId) {
      data.messageIds.forEach(msgId => {
        const msgEl = document.querySelector(`[data-msg-id="${msgId}"]`);
        if (msgEl) {
          const statusEl = msgEl.querySelector('.message-status');
          if (statusEl) {
            statusEl.innerHTML = '<i class="fas fa-check-double"></i>';
          }
        }
      });
    }
  });

  // Reactions
  state.socket.on('message:reaction:updated', (data) => {
    const msgIndex = state.messages.findIndex(m => m.id === data.messageId);
    if (msgIndex > -1) {
      state.messages[msgIndex].reactions = data.reactions;
    }

    const msgEl = document.querySelector(`[data-msg-id="${data.messageId}"]`);
    if (msgEl) {
      renderMessageReactions(msgEl, data.reactions);
    }
  });

  // Typing
  state.socket.on('typing:update', (data) => {
    if (state.currentChat?.id === data.chatId) {
      const indicator = document.getElementById('typingIndicator');
      const typingText = document.getElementById('typingText');
      if (data.isTyping) {
        typingText.textContent = `${data.displayName} печатает...`;
        indicator.style.display = 'flex';
      } else {
        indicator.style.display = 'none';
      }
    }
  });

  // User status
  state.socket.on('user:status', (data) => {
    // Update chat list status indicators
    state.chats.forEach(chat => {
      if (chat.members) {
        const member = chat.members.find(m => m.id === data.userId);
        if (member) member.status = data.status;
      }
    });

    // Update header status
    if (state.currentChat) {
      const otherMember = state.currentChat.members?.find(m => m.id !== state.user.id);
      if (otherMember?.id === data.userId) {
        const statusEl = document.getElementById('chatHeaderStatus');
        statusEl.textContent = data.status === 'online' ? 'онлайн' : 'был(а) недавно';
        statusEl.style.color = data.status === 'online' ? 'var(--success)' : 'var(--text-muted)';
      }
    }

    renderChatList();
  });

  // Notifications
  state.socket.on('notification', (data) => {
    if (data.type === 'message' && data.chatId !== state.currentChat?.id) {
      showToast(`Новое сообщение от ${data.message.sender_name}`, 'info');
    }
  });

  // Calls
  state.socket.on('call:incoming', (data) => {
    if (data.callerId !== state.user.id) {
      showIncomingCall(data);
    }
  });

  state.socket.on('call:ended', () => {
    hideCallModal();
  });

  state.socket.on('call:rejected', () => {
    hideCallModal();
    showToast('Звонок отклонен', 'info');
  });
}

// ============ API HELPERS ============
async function api(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${state.token}`,
      ...options.headers
    }
  });

  if (res.status === 401) {
    logout();
    return null;
  }

  return res.json();
}

// ============ LOAD DATA ============
async function loadChats() {
  const chats = await api('/api/chats');
  if (chats) {
    state.chats = chats;
    renderChatList();
  }
}

async function loadMessages(chatId) {
  const messages = await api(`/api/chats/${chatId}/messages`);
  if (messages) {
    state.messages = messages;
    renderMessages();
    scrollToBottom();

    // Mark unread messages as read
    const unreadIds = messages
      .filter(m => m.sender_id !== state.user.id && !m.reads?.some(r => r.user_id === state.user.id))
      .map(m => m.id);

    if (unreadIds.length > 0) {
      state.socket.emit('message:read', {
        chatId,
        messageIds: unreadIds
      });
    }
  }
}

async function loadStories() {
  const stories = await api('/api/stories');
  if (stories) {
    renderStories(stories);
  }
}

// ============ RENDER CHAT LIST ============
function renderChatList() {
  const container = document.getElementById('chatList');

  if (state.chats.length === 0) {
    container.innerHTML = `
      <div class="chat-list-empty">
        <i class="fas fa-comments"></i>
        <p>Нет чатов</p>
        <small>Начните новый разговор</small>
      </div>`;
    return;
  }

  container.innerHTML = state.chats.map(chat => {
    const isActive = state.currentChat?.id === chat.id;
    const lastMsg = chat.last_message;
    const isOnline = chat.type === 'private' && chat.members?.some(m => m.id !== state.user.id && m.status === 'online');

    let lastMsgText = '';
    if (lastMsg) {
      if (lastMsg.deleted) {
        lastMsgText = '🚫 Сообщение удалено';
      } else if (lastMsg.type === 'image') {
        lastMsgText = '📷 Фото';
      } else if (lastMsg.type === 'video') {
        lastMsgText = '🎬 Видео';
      } else if (lastMsg.type === 'file') {
        lastMsgText = '📎 Файл';
      } else if (lastMsg.type === 'audio') {
        lastMsgText = '🎵 Аудио';
      } else if (lastMsg.type === 'system') {
        lastMsgText = lastMsg.content;
      } else {
        const prefix = lastMsg.sender_id === state.user.id ? 'Вы: ' : '';
        lastMsgText = prefix + (lastMsg.content || '');
      }
    }

    const timeStr = lastMsg ? formatTime(lastMsg.created_at) : '';
    const avatarContent = chat.avatar
      ? `<img src="${chat.avatar}" alt="">`
      : getInitials(chat.name || 'C');

    return `
      <div class="chat-list-item ${isActive ? 'active' : ''}"
           onclick="openChat('${chat.id}')"
           oncontextmenu="showChatContextMenu(event, '${chat.id}')">
        ${chat.pinned ? '<span class="pinned-icon"><i class="fas fa-thumbtack"></i></span>' : ''}
        <div class="chat-avatar">
          ${avatarContent}
          ${isOnline ? '<span class="online-dot"></span>' : ''}
        </div>
        <div class="chat-info">
          <div class="chat-info-top">
            <span class="chat-name">${escapeHtml(chat.name || 'Чат')}</span>
            <span class="chat-time">${timeStr}</span>
          </div>
          <div class="chat-info-bottom">
            <span class="chat-last-msg">${escapeHtml(lastMsgText)}</span>
            ${chat.unread_count > 0 ? `<span class="chat-badge">${chat.unread_count}</span>` : ''}
          </div>
        </div>
      </div>`;
  }).join('');
}

// ============ OPEN CHAT ============
async function openChat(chatId) {
  const chat = state.chats.find(c => c.id === chatId);
  if (!chat) return;

  state.currentChat = chat;

  // Reset unread
  const chatIndex = state.chats.findIndex(c => c.id === chatId);
  if (chatIndex > -1) state.chats[chatIndex].unread_count = 0;

  // Show chat view
  document.getElementById('noChatSelected').style.display = 'none';
  document.getElementById('chatView').style.display = 'flex';
  document.getElementById('chatView').style.flexDirection = 'column';

  // Update header
  const headerAvatar = document.getElementById('chatHeaderAvatar');
  headerAvatar.innerHTML = chat.avatar
    ? `<img src="${chat.avatar}" alt="">`
    : getInitials(chat.name || 'C');

  document.getElementById('chatHeaderName').textContent = chat.name || 'Чат';

  const otherMember = chat.members?.find(m => m.id !== state.user.id);
  const statusEl = document.getElementById('chatHeaderStatus');
  if (chat.type === 'private' && otherMember) {
    statusEl.textContent = otherMember.status === 'online' ? 'онлайн' : 'был(а) недавно';
    statusEl.style.color = otherMember.status === 'online' ? 'var(--success)' : 'var(--text-muted)';
  } else {
    statusEl.textContent = `${chat.member_count || 0} участников`;
    statusEl.style.color = 'var(--text-muted)';
  }

  // Mobile: hide sidebar
  if (window.innerWidth <= 768) {
    document.getElementById('sidebar').style.display = 'none';
  }

  renderChatList();
  await loadMessages(chatId);

  // Focus input
  document.getElementById('messageInput').focus();
}

function closeChat() {
  state.currentChat = null;
  document.getElementById('noChatSelected').style.display = 'flex';
  document.getElementById('chatView').style.display = 'none';

  if (window.innerWidth <= 768) {
    document.getElementById('sidebar').style.display = 'flex';
  }

  renderChatList();
}

// ============ RENDER MESSAGES ============
function renderMessages() {
  const container = document.getElementById('messagesList');
  container.innerHTML = '';

  let lastDate = '';

  state.messages.forEach(msg => {
    const msgDate = new Date(msg.created_at).toLocaleDateString('ru-RU', {
      day: 'numeric', month: 'long', year: 'numeric'
    });

    if (msgDate !== lastDate) {
      lastDate = msgDate;
      container.innerHTML += `
        <div class="date-separator">
          <span>${msgDate}</span>
        </div>`;
    }

    container.innerHTML += createMessageHTML(msg);
  });
}

function renderNewMessage(msg) {
  const container = document.getElementById('messagesList');
  container.innerHTML += createMessageHTML(msg);
}

function createMessageHTML(msg) {
  if (msg.type === 'system') {
    return `
      <div class="message system-message">
        <div class="message-bubble">${escapeHtml(msg.content)}</div>
      </div>`;
  }

  const isSent = msg.sender_id === state.user.id;
  const classes = `message ${isSent ? 'sent' : 'received'}`;

  const avatarContent = msg.sender_avatar
    ? `<img src="${msg.sender_avatar}" alt="">`
    : getInitials(msg.sender_name || 'U');

  let contentHTML = '';

  if (msg.deleted) {
    contentHTML = '<span class="message-deleted"><i class="fas fa-ban"></i> Сообщение удалено</span>';
  } else {
    // Reply
    if (msg.reply_message) {
      contentHTML += `
        <div class="message-reply">
          <strong>${escapeHtml(msg.reply_message.sender_name)}</strong>
          ${escapeHtml(msg.reply_message.content || (msg.reply_message.type === 'image' ? '📷 Фото' : '📎 Файл'))}
        </div>`;
    }

    // Forwarded
    if (msg.forwarded_from) {
      contentHTML += `<div class="message-forwarded"><i class="fas fa-share"></i> Переслано</div>`;
    }

    // Content by type
    switch (msg.type) {
      case 'image':
        contentHTML += `<img class="message-image" src="${msg.file_url}" alt="" onclick="viewImage('${msg.file_url}')" loading="lazy">`;
        if (msg.content) contentHTML += `<div class="message-content">${formatMessageText(msg.content)}</div>`;
        break;
      case 'video':
        contentHTML += `<video class="message-video" controls preload="metadata"><source src="${msg.file_url}"></video>`;
        break;
      case 'audio':
        contentHTML += `<audio controls preload="metadata" style="max-width:250px;"><source src="${msg.file_url}"></audio>`;
        break;
      case 'file':
        contentHTML += `
          <a href="${msg.file_url}" download="${escapeHtml(msg.file_name)}" class="message-file" target="_blank">
            <div class="message-file-icon"><i class="fas fa-file"></i></div>
            <div class="message-file-info">
              <div class="message-file-name">${escapeHtml(msg.file_name || 'Файл')}</div>
              <div class="message-file-size">${formatFileSize(msg.file_size)}</div>
            </div>
          </a>`;
        break;
      default:
        contentHTML += `<div class="message-content">${formatMessageText(msg.content)}</div>`;
    }
  }

  // Reactions
  let reactionsHTML = '';
  if (msg.reactions && msg.reactions.length > 0 && !msg.deleted) {
    const grouped = {};
    msg.reactions.forEach(r => {
      if (!grouped[r.emoji]) grouped[r.emoji] = { count: 0, users: [], own: false };
      grouped[r.emoji].count++;
      grouped[r.emoji].users.push(r.display_name);
      if (r.user_id === state.user.id) grouped[r.emoji].own = true;
    });

    reactionsHTML = '<div class="message-reactions">';
    for (const [emoji, data] of Object.entries(grouped)) {
      reactionsHTML += `
        <span class="reaction-badge ${data.own ? 'own' : ''}"
              onclick="toggleReaction('${msg.id}', '${emoji}')"
              title="${data.users.join(', ')}">
          ${emoji} <span class="reaction-count">${data.count}</span>
        </span>`;
    }
    reactionsHTML += '</div>';
  }

  // Status
  let statusHTML = '';
  if (isSent && !msg.deleted) {
    const isRead = msg.reads && msg.reads.some(r => r.user_id !== state.user.id);
    statusHTML = `<span class="message-status"><i class="fas fa-check${isRead ? '-double' : ''}"></i></span>`;
  }

  return `
    <div class="${classes}" data-msg-id="${msg.id}"
         oncontextmenu="showMessageContextMenu(event, '${msg.id}')">
      <div class="message-avatar">${avatarContent}</div>
      <div class="message-bubble">
        <div class="message-sender">${escapeHtml(msg.sender_name || 'User')}</div>
        ${contentHTML}
        <div class="message-meta">
          ${msg.edited ? '<span class="message-edited">изменено</span>' : ''}
          <span class="message-time">${formatTime(msg.created_at)}</span>
          ${statusHTML}
        </div>
        ${reactionsHTML}
      </div>
    </div>`;
}

function renderMessageReactions(msgEl, reactions) {
  let existing = msgEl.querySelector('.message-reactions');
  if (existing) existing.remove();

  if (!reactions || reactions.length === 0) return;

  const bubble = msgEl.querySelector('.message-bubble');
  const msgId = msgEl.getAttribute('data-msg-id');

  const grouped = {};
  reactions.forEach(r => {
    if (!grouped[r.emoji]) grouped[r.emoji] = { count: 0, users: [], own: false };
    grouped[r.emoji].count++;
    grouped[r.emoji].users.push(r.display_name);
    if (r.user_id === state.user.id) grouped[r.emoji].own = true;
  });

  let html = '<div class="message-reactions">';
  for (const [emoji, data] of Object.entries(grouped)) {
    html += `
      <span class="reaction-badge ${data.own ? 'own' : ''}"
            onclick="toggleReaction('${msgId}', '${emoji}')"
            title="${data.users.join(', ')}">
        ${emoji} <span class="reaction-count">${data.count}</span>
      </span>`;
  }
  html += '</div>';

  bubble.insertAdjacentHTML('beforeend', html);
}

// ============ SEND MESSAGE ============
function sendMessage() {
  const input = document.getElementById('messageInput');
  const content = input.value.trim();

  if (!content || !state.currentChat) return;

  state.socket.emit('message:send', {
    chatId: state.currentChat.id,
    content,
    type: 'text',
    replyTo: state.replyTo || ''
  });

  input.value = '';
  autoResize(input);
  cancelReply();
}

function handleInputKeydown(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

// ============ TYPING ============
let typingTimeout;
function handleTyping() {
  if (!state.currentChat) return;

  state.socket.emit('typing:start', { chatId: state.currentChat.id });

  clearTimeout(typingTimeout);
  typingTimeout = setTimeout(() => {
    state.socket.emit('typing:stop', { chatId: state.currentChat.id });
  }, 2000);
}

// ============ REPLY ============
function replyToMessage(messageId) {
  const msg = state.messages.find(m => m.id === messageId);
  if (!msg) return;

  state.replyTo = messageId;

  document.getElementById('replyPreview').style.display = 'flex';
  document.getElementById('replyPreviewName').textContent = msg.sender_name || 'User';
  document.getElementById('replyPreviewText').textContent = msg.content || (msg.type === 'image' ? '📷 Фото' : '📎 Файл');

  document.getElementById('messageInput').focus();
  closeAllMenus();
}

function cancelReply() {
  state.replyTo = null;
  document.getElementById('replyPreview').style.display = 'none';
}

// ============ FILE UPLOAD ============
function openAttachMenu() {
  const menu = document.getElementById('attachMenu');
  const visible = menu.style.display !== 'none';
  closeAllMenus();
  if (!visible) {
    menu.style.display = 'block';
  }
}

function attachFile(type) {
  closeAllMenus();
  const input = document.getElementById('fileInput');

  switch (type) {
    case 'image':
      input.accept = 'image/*';
      break;
    case 'video':
      input.accept = 'video/*';
      break;
    case 'audio':
      input.accept = 'audio/*';
      break;
    default:
      input.accept = '*/*';
  }

  input.click();
}

async function handleFileSelected(input) {
  if (!input.files.length || !state.currentChat) return;

  const file = input.files[0];

  const formData = new FormData();
  formData.append('file', file);

  showToast('Загрузка файла...', 'info');

  try {
    const res = await fetch('/api/upload', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${state.token}` },
      body: formData
    });

    const data = await res.json();

    if (!res.ok) {
      showToast(data.error || 'Ошибка загрузки', 'error');
      return;
    }

    let type = 'file';
    if (data.mimetype?.startsWith('image/')) type = 'image';
    else if (data.mimetype?.startsWith('video/')) type = 'video';
    else if (data.mimetype?.startsWith('audio/')) type = 'audio';

    state.socket.emit('message:send', {
      chatId: state.currentChat.id,
      content: '',
      type,
      fileUrl: data.url,
      fileName: data.name,
      fileSize: data.size,
      replyTo: state.replyTo || ''
    });

    cancelReply();
  } catch (err) {
    showToast('Ошибка загрузки файла', 'error');
  }

  input.value = '';
}

// ============ REACTIONS ============
function toggleReaction(messageId, emoji) {
  state.socket.emit('message:reaction', { messageId, emoji });
}

// ============ CONTEXT MENUS ============
function showMessageContextMenu(e, messageId) {
  e.preventDefault();
  closeAllMenus();

  const msg = state.messages.find(m => m.id === messageId);
  if (!msg || msg.deleted) return;

  const menu = document.getElementById('contextMenu');
  const isSent = msg.sender_id === state.user.id;

  let items = `
    <div class="context-item" onclick="replyToMessage('${messageId}')">
      <i class="fas fa-reply"></i> Ответить
    </div>
    <div class="context-item" onclick="copyMessage('${messageId}')">
      <i class="fas fa-copy"></i> Копировать
    </div>
    <div class="context-item" onclick="forwardMessage('${messageId}')">
      <i class="fas fa-share"></i> Переслать
    </div>
    <div class="context-item" onclick="showReactionPicker('${messageId}')">
      <i class="fas fa-smile"></i> Реакция
    </div>`;

  if (isSent) {
    items += `
      <div class="context-divider"></div>
      <div class="context-item" onclick="editMessage('${messageId}')">
        <i class="fas fa-edit"></i> Редактировать
      </div>
      <div class="context-item danger" onclick="deleteMessage('${messageId}')">
        <i class="fas fa-trash"></i> Удалить
      </div>`;
  }

  menu.innerHTML = items;
  menu.style.display = 'block';

  // Position
  const x = Math.min(e.clientX, window.innerWidth - 200);
  const y = Math.min(e.clientY, window.innerHeight - 250);
  menu.style.left = x + 'px';
  menu.style.top = y + 'px';
}

function showChatContextMenu(e, chatId) {
  e.preventDefault();
  // Simple pin/mute via regular click
}

function copyMessage(messageId) {
  const msg = state.messages.find(m => m.id === messageId);
  if (msg) {
    navigator.clipboard.writeText(msg.content).then(() => {
      showToast('Скопировано', 'success');
    });
  }
  closeAllMenus();
}

function editMessage(messageId) {
  const msg = state.messages.find(m => m.id === messageId);
  if (!msg) return;

  const newContent = prompt('Редактировать сообщение:', msg.content);
  if (newContent !== null && newContent.trim() !== '') {
    state.socket.emit('message:edit', { messageId, content: newContent.trim() });
  }
  closeAllMenus();
}

function deleteMessage(messageId) {
  if (confirm('Удалить сообщение?')) {
    state.socket.emit('message:delete', { messageId });
  }
  closeAllMenus();
}

function forwardMessage(messageId) {
  const msg = state.messages.find(m => m.id === messageId);
  if (!msg) return;

  // Simple forward - show chat selection
  const chatNames = state.chats.map((c, i) => `${i + 1}. ${c.name}`).join('\n');
  const choice = prompt(`Переслать в:\n${chatNames}\n\nВведите номер:`);
  if (choice) {
    const idx = parseInt(choice) - 1;
    if (state.chats[idx]) {
      state.socket.emit('message:send', {
        chatId: state.chats[idx].id,
        content: msg.content,
        type: msg.type,
        fileUrl: msg.file_url,
        fileName: msg.file_name,
        fileSize: msg.file_size,
        forwardedFrom: msg.sender_id
      });
      showToast('Сообщение переслано', 'success');
    }
  }
  closeAllMenus();
}

function showReactionPicker(messageId) {
  const emojis = ['👍', '❤️', '😂', '😮', '😢', '🔥', '👏', '🎉'];
  const menu = document.getElementById('contextMenu');
  menu.innerHTML = `
    <div style="display:flex; gap:4px; padding:8px;">
      ${emojis.map(e => `
        <span class="emoji-item" onclick="toggleReaction('${messageId}', '${e}'); closeAllMenus();">${e}</span>
      `).join('')}
    </div>`;
}

// ============ NEW CHAT ============
function toggleNewChat() {
  const modal = document.getElementById('newChatModal');
  modal.classList.toggle('show');
  closeAllMenus();
}

function switchNewChatTab(tab) {
  document.querySelectorAll('#newChatModal .modal-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.new-chat-tab').forEach(t => { t.style.display = 'none'; t.classList.remove('active'); });

  const tabEl = document.getElementById(`newChat${tab.charAt(0).toUpperCase() + tab.slice(1)}`);
  tabEl.style.display = 'block';
  tabEl.classList.add('active');

  event.target.classList.add('active');
}

async function searchUsers(query) {
  if (query.length < 2) {
    document.getElementById('userSearchResults').innerHTML = '';
    return;
  }

  const users = await api(`/api/users/search?q=${encodeURIComponent(query)}`);
  if (!users) return;

  document.getElementById('userSearchResults').innerHTML = users.map(u => `
    <div class="user-result-item" onclick="startPrivateChat('${u.id}')">
      <div class="user-result-avatar">
        ${u.avatar ? `<img src="${u.avatar}" alt="">` : getInitials(u.display_name)}
      </div>
      <div class="user-result-info">
        <div class="user-result-name">${escapeHtml(u.display_name)}</div>
        <div class="user-result-username">@${escapeHtml(u.username)}</div>
      </div>
    </div>
  `).join('');
}

async function searchUsersForGroup(query) {
  if (query.length < 2) {
    document.getElementById('groupUserResults').innerHTML = '';
    return;
  }

  const users = await api(`/api/users/search?q=${encodeURIComponent(query)}`);
  if (!users) return;

  document.getElementById('groupUserResults').innerHTML = users
    .filter(u => !state.selectedMembers.some(m => m.id === u.id))
    .map(u => `
      <div class="user-result-item" onclick="addGroupMember('${u.id}', '${escapeHtml(u.display_name)}')">
        <div class="user-result-avatar">
          ${u.avatar ? `<img src="${u.avatar}" alt="">` : getInitials(u.display_name)}
        </div>
        <div class="user-result-info">
          <div class="user-result-name">${escapeHtml(u.display_name)}</div>
          <div class="user-result-username">@${escapeHtml(u.username)}</div>
        </div>
      </div>
    `).join('');
}

function addGroupMember(userId, displayName) {
  if (state.selectedMembers.some(m => m.id === userId)) return;

  state.selectedMembers.push({ id: userId, name: displayName });
  renderSelectedMembers();
}

function removeGroupMember(userId) {
  state.selectedMembers = state.selectedMembers.filter(m => m.id !== userId);
  renderSelectedMembers();
}

function renderSelectedMembers() {
  document.getElementById('selectedMembers').innerHTML = state.selectedMembers.map(m => `
    <div class="selected-member">
      <span class="mini-avatar">${getInitials(m.name)}</span>
      ${escapeHtml(m.name)}
      <button onclick="removeGroupMember('${m.id}')">&times;</button>
    </div>
  `).join('');
}

async function startPrivateChat(userId) {
  const chat = await api('/api/chats', {
    method: 'POST',
    body: JSON.stringify({ type: 'private', members: [userId] })
  });

  if (chat) {
    toggleNewChat();
    await loadChats();
    openChat(chat.id);
  }
}

async function createGroup() {
  const name = document.getElementById('groupName').value.trim();
  const description = document.getElementById('groupDescription').value.trim();

  if (!name) {
    showToast('Введите название группы', 'error');
    return;
  }

  const chat = await api('/api/chats', {
    method: 'POST',
    body: JSON.stringify({
      type: 'group',
      name,
      description,
      members: state.selectedMembers.map(m => m.id)
    })
  });

  if (chat) {
    toggleNewChat();
    state.selectedMembers = [];
    document.getElementById('groupName').value = '';
    document.getElementById('groupDescription').value = '';
    await loadChats();
    openChat(chat.id);
  }
}

async function createChannel() {
  const name = document.getElementById('channelName').value.trim();
  const description = document.getElementById('channelDescription').value.trim();

  if (!name) {
    showToast('Введите название канала', 'error');
    return;
  }

  const chat = await api('/api/chats', {
    method: 'POST',
    body: JSON.stringify({ type: 'channel', name, description })
  });

  if (chat) {
    toggleNewChat();
    document.getElementById('channelName').value = '';
    document.getElementById('channelDescription').value = '';
    await loadChats();
    openChat(chat.id);
  }
}

// ============ SEARCH ============
function handleSearch(query) {
  if (!query) {
    renderChatList();
    return;
  }

  const filtered = state.chats.filter(c =>
    (c.name || '').toLowerCase().includes(query.toLowerCase())
  );

  const container = document.getElementById('chatList');
  if (filtered.length === 0) {
    container.innerHTML = '<div class="chat-list-empty"><p>Ничего не найдено</p></div>';
    return;
  }

  // Re-render with filtered chats (simplified)
  const temp = state.chats;
  state.chats = filtered;
  renderChatList();
  state.chats = temp;
}

function toggleSearchMessages() {
  const bar = document.getElementById('messagesSearchBar');
  bar.style.display = bar.style.display === 'none' ? 'flex' : 'none';
  if (bar.style.display === 'flex') {
    bar.querySelector('input').focus();
  }
}

async function searchMessages(query) {
  if (!query || !state.currentChat) return;

  const results = await api(`/api/chats/${state.currentChat.id}/messages/search?q=${encodeURIComponent(query)}`);
  if (results && results.length > 0) {
    showToast(`Найдено ${results.length} сообщений`, 'info');
    // Highlight first result
    const msgEl = document.querySelector(`[data-msg-id="${results[0].id}"]`);
    if (msgEl) {
      msgEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      msgEl.style.background = 'rgba(102, 126, 234, 0.2)';
      setTimeout(() => { msgEl.style.background = ''; }, 2000);
    }
  }
}

// ============ CHAT INFO PANEL ============
function toggleChatInfo() {
  const panel = document.getElementById('rightPanel');
  if (panel.style.display === 'none') {
    renderChatInfoPanel();
    panel.style.display = 'flex';
    panel.style.flexDirection = 'column';
  } else {
    panel.style.display = 'none';
  }
}

function closeRightPanel() {
  document.getElementById('rightPanel').style.display = 'none';
}

function renderChatInfoPanel() {
  const chat = state.currentChat;
  if (!chat) return;

  const content = document.getElementById('rightPanelContent');

  const avatarContent = chat.avatar
    ? `<img src="${chat.avatar}" alt="">`
    : getInitials(chat.name || 'C');

  let membersHTML = '';
  if (chat.members) {
    membersHTML = `
      <div class="panel-section">
        <div class="panel-section-title">Участники (${chat.members.length})</div>
        ${chat.members.map(m => `
          <div class="panel-member">
            <div class="panel-member-avatar">
              ${m.avatar ? `<img src="${m.avatar}" alt="">` : getInitials(m.display_name)}
            </div>
            <div>
              <div class="panel-member-name">${escapeHtml(m.display_name)}</div>
              <div class="panel-member-role">${m.role === 'admin' ? '👑 Админ' : m.status === 'online' ? '🟢 онлайн' : 'оффлайн'}</div>
            </div>
          </div>
        `).join('')}
      </div>`;
  }

  // Media
  const mediaMessages = state.messages.filter(m => m.type === 'image' && !m.deleted);
  let mediaHTML = '';
  if (mediaMessages.length > 0) {
    mediaHTML = `
      <div class="panel-section">
        <div class="panel-section-title">Медиа (${mediaMessages.length})</div>
        <div class="panel-media-grid">
          ${mediaMessages.slice(-9).map(m => `
            <div class="panel-media-item" onclick="viewImage('${m.file_url}')">
              <img src="${m.file_url}" alt="" loading="lazy">
            </div>
          `).join('')}
        </div>
      </div>`;
  }

  content.innerHTML = `
    <div class="panel-avatar">${avatarContent}</div>
    <div class="panel-name">${escapeHtml(chat.name || 'Чат')}</div>
    <div class="panel-status">
      ${chat.type === 'private' ? '' : `${chat.type === 'group' ? 'Группа' : 'Канал'} · ${chat.member_count || 0} участников`}
    </div>
    ${chat.description ? `
      <div class="panel-section">
        <div class="panel-section-title">Описание</div>
        <p style="font-size:14px; color: var(--text-secondary);">${escapeHtml(chat.description)}</p>
      </div>
    ` : ''}
    ${membersHTML}
    ${mediaHTML}
  `;
}

// ============ STORIES ============
function renderStories(storiesData) {
  const container = document.getElementById('storiesList');
  container.innerHTML = storiesData.map(group => {
    const hasUnviewed = group.stories.some(s => !s.viewed);
    return `
      <div class="story-item" onclick="viewStory('${group.user_id}')">
        <div class="story-avatar-wrap" style="${hasUnviewed ? '' : 'background: var(--border)'}">
          <div class="story-avatar">
            ${group.avatar ? `<img src="${group.avatar}" alt="">` : getInitials(group.display_name)}
          </div>
        </div>
        <span>${escapeHtml(group.display_name?.split(' ')[0] || group.username)}</span>
      </div>`;
  }).join('');
}

let currentStories = [];
let currentStoryIndex = 0;
let storyTimer;

async function viewStory(userId) {
  const stories = await api('/api/stories');
  if (!stories) return;

  const group = stories.find(g => g.user_id === userId);
  if (!group || !group.stories.length) return;

  currentStories = group.stories;
  currentStoryIndex = 0;

  document.getElementById('storyViewerName').textContent = group.display_name;
  const avatarEl = document.getElementById('storyViewerAvatar');
  avatarEl.innerHTML = group.avatar ? `<img src="${group.avatar}" alt="">` : '';

  // Progress bars
  const progressContainer = document.getElementById('storyProgress');
  progressContainer.innerHTML = currentStories.map((_, i) => `
    <div class="story-progress-bar">
      <div class="story-progress-fill" id="storyProgressFill${i}" style="width: 0%"></div>
    </div>
  `).join('');

  document.getElementById('storyViewer').style.display = 'flex';
  showStoryContent(0);
}

function showStoryContent(index) {
  if (index >= currentStories.length) {
    closeStoryViewer();
    return;
  }

  currentStoryIndex = index;
  const story = currentStories[index];
  const contentEl = document.getElementById('storyViewerContent');
  const timeEl = document.getElementById('storyViewerTime');

  timeEl.textContent = formatTimeAgo(story.created_at);

  // Mark previous as complete
  for (let i = 0; i < index; i++) {
    const fill = document.getElementById(`storyProgressFill${i}`);
    if (fill) fill.style.width = '100%';
  }

  // Reset current and future
  for (let i = index; i < currentStories.length; i++) {
    const fill = document.getElementById(`storyProgressFill${i}`);
    if (fill) fill.style.width = '0%';
  }

  if (story.type === 'text') {
    contentEl.innerHTML = `<div class="text-story" style="background: ${story.bg_color}; padding: 40px; border-radius: 20px;">${escapeHtml(story.content)}</div>`;
  } else {
    contentEl.innerHTML = `<img src="${story.file_url}" alt="">`;
  }

  // Mark as viewed
  api(`/api/stories/${story.id}/view`, { method: 'POST' });

  // Auto-progress
  clearInterval(storyTimer);
  let progress = 0;
  const fill = document.getElementById(`storyProgressFill${index}`);

  storyTimer = setInterval(() => {
    progress += 2;
    if (fill) fill.style.width = progress + '%';
    if (progress >= 100) {
      clearInterval(storyTimer);
      showStoryContent(index + 1);
    }
  }, 100);
}

function nextStory() {
  clearInterval(storyTimer);
  showStoryContent(currentStoryIndex + 1);
}

function prevStory() {
  clearInterval(storyTimer);
  showStoryContent(Math.max(0, currentStoryIndex - 1));
}

function closeStoryViewer() {
  clearInterval(storyTimer);
  document.getElementById('storyViewer').style.display = 'none';
}

function createStory() {
  document.getElementById('createStoryModal').style.display = 'flex';
}

function closeCreateStory() {
  document.getElementById('createStoryModal').style.display = 'none';
}

function switchStoryType(type) {
  document.querySelectorAll('#createStoryModal .modal-tab').forEach(t => t.classList.remove('active'));
  event.target.classList.add('active');

  document.getElementById('storyTextForm').style.display = type === 'text' ? 'block' : 'none';
  document.getElementById('storyImageForm').style.display = type === 'image' ? 'block' : 'none';
}

function selectStoryColor(el) {
  document.querySelectorAll('.story-color').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  state.storyColor = el.dataset.color;
}

function previewStoryImage(input) {
  if (input.files.length) {
    const preview = document.getElementById('storyImagePreview');
    preview.src = URL.createObjectURL(input.files[0]);
    preview.style.display = 'block';
  }
}

async function publishStory() {
  const textInput = document.getElementById('storyTextInput');
  const imageInput = document.getElementById('storyImageInput');

  if (document.getElementById('storyTextForm').style.display !== 'none') {
    // Text story
    const content = textInput.value.trim();
    if (!content) {
      showToast('Напишите что-нибудь', 'error');
      return;
    }

    await api('/api/stories', {
      method: 'POST',
      body: JSON.stringify({
        content,
        type: 'text',
        bgColor: state.storyColor
      })
    });
  } else {
    // Image story
    if (!imageInput.files.length) {
      showToast('Выберите фото', 'error');
      return;
    }

    const formData = new FormData();
    formData.append('file', imageInput.files[0]);

    const uploadRes = await fetch('/api/upload', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${state.token}` },
      body: formData
    });

    const uploadData = await uploadRes.json();

    await api('/api/stories', {
      method: 'POST',
      body: JSON.stringify({
        type: 'image',
        fileUrl: uploadData.url
      })
    });
  }

  closeCreateStory();
  textInput.value = '';
  imageInput.value = '';
  document.getElementById('storyImagePreview').style.display = 'none';
  loadStories();
  showToast('История опубликована!', 'success');
}

// ============ EMOJI PICKER ============
const EMOJIS = [
  '😀','😁','😂','🤣','😃','😄','😅','😆','😉','😊',
  '😋','😎','😍','🥰','😘','😗','😙','😚','🤗','🤔',
  '🤐','🤨','😐','😑','😶','😏','😒','🙄','😬','🤥',
  '😌','😔','😪','🤤','😴','😷','🤒','🤕','🤢','🤮',
  '🤧','🥵','🥶','🥴','😵','🤯','🤠','🥳','😎','🤓',
  '🧐','😕','😟','🙁','😮','😯','😲','😳','🥺','😦',
  '😧','😨','😰','😥','😢','😭','😱','😖','😣','😞',
  '😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿',
  '💀','☠️','💩','🤡','👹','👺','👻','👽','👾','🤖',
  '😺','😸','😹','😻','😼','😽','🙀','😿','😾',
  '👋','🤚','🖐️','✋','🖖','👌','🤌','🤏','✌️','🤞',
  '🤟','🤘','🤙','👈','👉','👆','🖕','👇','☝️','👍',
  '👎','✊','👊','🤛','🤜','👏','🙌','👐','🤲','🤝',
  '🙏','✍️','💅','🤳','💪','🦾','🦿','🦵','🦶','👂',
  '❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔',
  '❣️','💕','💞','💓','💗','💖','💘','💝','💟',
  '⭐','🌟','✨','⚡','🔥','💯','🎉','🎊','🎈','🎁',
  '🏆','🥇','🥈','🥉','⚽','🏀','🏈','⚾','🎾','🏐',
  '🍕','🍔','🍟','🌭','🍿','🧁','🍩','🍪','🎂','🍰',
  '☕','🍵','🥤','🍺','🍷','🥂','🍾',
  '👍','👎','👏','🙏','💪','🔥','❤️','😂','😭','🥺'
];

function initEmojiPicker() {
  const grid = document.getElementById('emojiGrid');
  grid.innerHTML = EMOJIS.map(e => `
    <span class="emoji-item" onclick="insertEmoji('${e}')">${e}</span>
  `).join('');
  state.emojiList = EMOJIS;
}

function toggleEmojiPicker() {
  const picker = document.getElementById('emojiPicker');
  const visible = picker.style.display !== 'none';
  closeAllMenus();
  if (!visible) {
    picker.style.display = 'flex';
    picker.style.flexDirection = 'column';
  }
}

function insertEmoji(emoji) {
  const input = document.getElementById('messageInput');
  input.value += emoji;
  input.focus();
}

function filterEmoji(query) {
  // Simple filter by matching emoji names - just show all if empty
  const grid = document.getElementById('emojiGrid');
  if (!query) {
    grid.innerHTML = EMOJIS.map(e => `
      <span class="emoji-item" onclick="insertEmoji('${e}')">${e}</span>
    `).join('');
  }
}

// ============ CALLS ============
function startCall(type) {
  if (!state.currentChat) return;

  state.socket.emit('call:start', {
    chatId: state.currentChat.id,
    type
  });

  const callModal = document.getElementById('callModal');
  callModal.style.display = 'flex';

  document.getElementById('callName').textContent = state.currentChat.name || 'Звонок';
  document.getElementById('callStatus').textContent = type === 'voice' ? 'Голосовой звонок...' : 'Видеозвонок...';

  const avatarEl = document.getElementById('callAvatar');
  avatarEl.innerHTML = state.currentChat.avatar
    ? `<img src="${state.currentChat.avatar}" alt="">`
    : `<i class="fas fa-${type === 'voice' ? 'phone' : 'video'}"></i>`;
}

function showIncomingCall(data) {
  const accept = confirm(`Входящий ${data.type === 'voice' ? 'голосовой' : 'видео'} звонок от ${data.callerName}. Принять?`);

  if (accept) {
    state.socket.emit('call:accept', { callId: data.callId, chatId: data.chatId });

    const callModal = document.getElementById('callModal');
    callModal.style.display = 'flex';
    document.getElementById('callName').textContent = data.callerName;
    document.getElementById('callStatus').textContent = 'Соединение...';
  } else {
    state.socket.emit('call:reject', { callId: data.callId, chatId: data.chatId });
  }
}

function endCall() {
  if (state.currentChat) {
    state.socket.emit('call:end', { callId: '', chatId: state.currentChat.id });
  }
  hideCallModal();
}

function hideCallModal() {
  document.getElementById('callModal').style.display = 'none';
}

function toggleMute() {
  showToast('Микрофон переключен', 'info');
}

function toggleSpeaker() {
  showToast('Динамик переключен', 'info');
}

// ============ MENUS ============
function toggleMenu() {
  const menu = document.getElementById('mainMenu');
  const visible = menu.style.display !== 'none';
  closeAllMenus();
  if (!visible) {
    menu.style.display = 'block';
    menu.style.top = '60px';
    menu.style.left = `${Math.min(window.innerWidth - 220, 300)}px`;
  }
}

function toggleChatMenu() {
  const menu = document.getElementById('chatMenu');
  const visible = menu.style.display !== 'none';
  closeAllMenus();
  if (!visible) {
    menu.style.display = 'block';
    menu.style.top = '60px';
    menu.style.right = '20px';
    menu.style.left = 'auto';

    // Update text
    if (state.currentChat) {
      document.getElementById('muteText').textContent = state.currentChat.muted ? 'Включить уведомления' : 'Отключить уведомления';
      document.getElementById('pinText').textContent = state.currentChat.pinned ? 'Открепить' : 'Закрепить';
    }
  }
}

async function toggleMuteChat() {
  if (!state.currentChat) return;
  const newMuted = !state.currentChat.muted;
  await api(`/api/chats/${state.currentChat.id}/settings`, {
    method: 'PUT',
    body: JSON.stringify({ muted: newMuted })
  });
  state.currentChat.muted = newMuted;
  showToast(newMuted ? 'Уведомления отключены' : 'Уведомления включены', 'info');
  closeAllMenus();
}

async function togglePinChat() {
  if (!state.currentChat) return;
  const newPinned = !state.currentChat.pinned;
  await api(`/api/chats/${state.currentChat.id}/settings`, {
    method: 'PUT',
    body: JSON.stringify({ pinned: newPinned })
  });
  state.currentChat.pinned = newPinned;
  await loadChats();
  showToast(newPinned ? 'Чат закреплен' : 'Чат откреплен', 'info');
  closeAllMenus();
}

function clearChat() {
  showToast('Чат очищен (локально)', 'info');
  state.messages = [];
  renderMessages();
  closeAllMenus();
}

async function deleteChat() {
  if (!confirm('Удалить чат? Это действие нельзя отменить.')) return;

  if (state.currentChat) {
    await api(`/api/chats/${state.currentChat.id}/members/${state.user.id}`, { method: 'DELETE' });
    closeChat();
    await loadChats();
  }
  closeAllMenus();
}

function closeAllMenus() {
  document.getElementById('contextMenu').style.display = 'none';
  document.getElementById('mainMenu').style.display = 'none';
  document.getElementById('chatMenu').style.display = 'none';
  document.getElementById('attachMenu').style.display = 'none';
  document.getElementById('emojiPicker').style.display = 'none';
}

// Close menus on click outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('.context-menu') && !e.target.closest('.dropdown-menu') &&
      !e.target.closest('.attach-menu') && !e.target.closest('.emoji-picker') &&
      !e.target.closest('.icon-btn') && !e.target.closest('.attach-btn')) {
    closeAllMenus();
  }
});

// ============ SETTINGS ============
function openSettings() {
  closeAllMenus();
  const modal = document.getElementById('settingsModal');
  modal.style.display = 'flex';

  document.getElementById('settingsDisplayName').value = state.user.display_name || '';
  document.getElementById('settingsBio').value = state.user.bio || '';

  const avatarEl = document.getElementById('settingsAvatar');
  avatarEl.innerHTML = state.user.avatar
    ? `<img src="${state.user.avatar}" alt="">`
    : '<i class="fas fa-camera"></i>';
}

function closeSettings() {
  document.getElementById('settingsModal').style.display = 'none';
}

async function saveSettings() {
  const displayName = document.getElementById('settingsDisplayName').value.trim();
  const bio = document.getElementById('settingsBio').value.trim();

  const user = await api('/api/users/me', {
    method: 'PUT',
    body: JSON.stringify({ displayName, bio })
  });

  if (user) {
    state.user = user;
    localStorage.setItem('impuls_user', JSON.stringify(user));
    showToast('Настройки сохранены', 'success');
    closeSettings();
  }
}

async function uploadAvatar(input) {
  if (!input.files.length) return;

  const formData = new FormData();
  formData.append('avatar', input.files[0]);

  const res = await fetch('/api/upload/avatar', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${state.token}` },
    body: formData
  });

  const data = await res.json();

  if (data.url) {
    state.user.avatar = data.url;
    localStorage.setItem('impuls_user', JSON.stringify(state.user));

    document.getElementById('settingsAvatar').innerHTML = `<img src="${data.url}" alt="">`;
    showToast('Аватар обновлен', 'success');
  }
}

// ============ CONTACTS ============
function openContacts() {
  closeAllMenus();
  document.getElementById('contactsModal').style.display = 'flex';
  loadContacts();
}

function closeContacts() {
  document.getElementById('contactsModal').style.display = 'none';
}

async function loadContacts() {
  const contacts = await api('/api/contacts');
  if (!contacts) return;

  const container = document.getElementById('contactsList');
  if (contacts.length === 0) {
    container.innerHTML = '<p style="text-align:center; color: var(--text-muted); padding: 20px;">Нет контактов</p>';
    return;
  }

  container.innerHTML = contacts.map(c => `
    <div class="contact-item" onclick="startPrivateChat('${c.id}'); closeContacts();">
      <div class="user-result-avatar">
        ${c.avatar ? `<img src="${c.avatar}" alt="">` : getInitials(c.display_name)}
      </div>
      <div class="user-result-info">
        <div class="user-result-name">${escapeHtml(c.display_name)}</div>
        <div class="user-result-username">${c.status === 'online' ? '🟢 онлайн' : 'оффлайн'}</div>
      </div>
    </div>
  `).join('');
}

function searchContacts(query) {
  // Filter displayed contacts
  const items = document.querySelectorAll('.contact-item');
  items.forEach(item => {
    const name = item.querySelector('.user-result-name')?.textContent || '';
    item.style.display = name.toLowerCase().includes(query.toLowerCase()) ? 'flex' : 'none';
  });
}

// ============ THEME ============
function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  localStorage.setItem('impuls_theme', state.theme);

  if (state.theme === 'light') {
    document.documentElement.setAttribute('data-theme', 'light');
  } else {
    document.documentElement.removeAttribute('data-theme');
  }

  closeAllMenus();
  showToast(`Тема: ${state.theme === 'dark' ? 'Тёмная' : 'Светлая'}`, 'info');
}

// ============ IMAGE VIEWER ============
function viewImage(url) {
  document.getElementById('imageViewerImg').src = url;
  document.getElementById('imageViewer').style.display = 'flex';
}

function closeImageViewer() {
  document.getElementById('imageViewer').style.display = 'none';
}

// ============ UTILITY FUNCTIONS ============
function formatTime(dateStr) {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  const now = new Date();
  const diff = now - date;

  if (diff < 86400000 && date.getDate() === now.getDate()) {
    return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  } else if (diff < 172800000) {
    return 'Вчера';
  } else if (diff < 604800000) {
    return date.toLocaleDateString('ru-RU', { weekday: 'short' });
  } else {
    return date.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' });
  }
}

function formatTimeAgo(dateStr) {
  const date = new Date(dateStr);
  const diff = Date.now() - date;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);

  if (minutes < 1) return 'только что';
  if (minutes < 60) return `${minutes} мин назад`;
  if (hours < 24) return `${hours} ч назад`;
  return date.toLocaleDateString('ru-RU');
}

function formatFileSize(bytes) {
  if (!bytes) return '';
  if (bytes < 1024) return bytes + ' Б';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' КБ';
  return (bytes / 1048576).toFixed(1) + ' МБ';
}

function formatMessageText(text) {
  if (!text) return '';
  let html = escapeHtml(text);

  // URLs
  html = html.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank" style="color: #4fc3f7; text-decoration: underline;">$1</a>');

  // Bold **text**
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

  // Italic *text*
  html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');

  // Code `text`
  html = html.replace(/`(.*?)`/g, '<code style="background: rgba(0,0,0,0.2); padding: 2px 6px; border-radius: 4px; font-family: monospace;">$1</code>');

  // Newlines
  html = html.replace(/\n/g, '<br>');

  return html;
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function getInitials(name) {
  if (!name) return '?';
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
}

function autoResize(textarea) {
  textarea.style.height = 'auto';
  textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
}

function scrollToBottom() {
  const container = document.getElementById('messagesContainer');
  setTimeout(() => {
    container.scrollTop = container.scrollHeight;
  }, 50);
}

function showToast(message, type = 'info') {
  const container = document.getElementById('toasts');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const icons = {
    success: 'fa-check-circle',
    error: 'fa-exclamation-circle',
    info: 'fa-info-circle'
  };

  toast.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i> ${escapeHtml(message)}`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'toastIn 0.3s ease reverse';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

function playNotificationSound() {
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    gainNode.gain.value = 0.1;

    oscillator.start();
    oscillator.stop(audioCtx.currentTime + 0.15);
  } catch (e) {}
}

function logout() {
  localStorage.removeItem('impuls_token');
  localStorage.removeItem('impuls_user');
  if (state.socket) state.socket.disconnect();
  window.location.href = '/';
}

// ============ INIT ============
function init() {
  connectSocket();
  initEmojiPicker();

  // Update my story avatar
  const myStoryAvatar = document.getElementById('myStoryAvatar');
  if (state.user.avatar) {
    myStoryAvatar.innerHTML = `<img src="${state.user.avatar}" alt="">`;
  }

  // Request notification permission
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }

  // Prevent context menu on app
  document.addEventListener('contextmenu', (e) => {
    if (e.target.closest('.message')) {
      e.preventDefault();
    }
  });

  // Keyboard shortcut: Escape to close modals
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeAllMenus();
      document.querySelectorAll('.modal.show').forEach(m => m.classList.remove('show'));
      document.getElementById('settingsModal').style.display = 'none';
      document.getElementById('contactsModal').style.display = 'none';
      document.getElementById('createStoryModal').style.display = 'none';
      closeStoryViewer();
      closeImageViewer();
      hideCallModal();
    }
  });
}

init();